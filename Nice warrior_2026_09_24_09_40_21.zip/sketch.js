let img


  function preload() {
  img= loadImage("dtr.png")
}
function setup() {
  createCanvas(400,400 );
}

function draw() {
  background(167,0,0);
  fill(0)
  fill(256,0,0)
  textSize(75)
  text("REVENGE",100,100,100)
  rect(0,270,400,130)
  image(img,-300,-200,1000,1000)
}